zip -r archive.zip *
